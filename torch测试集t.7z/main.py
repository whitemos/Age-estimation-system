import torch
import torchvision.models as models
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Dataset
from PIL import Image
import os
import re
from torchvision import transforms

# 假设你的原始图像是灰度图（单通道）
transform = transforms.Compose([
    transforms.Grayscale(num_output_channels=3), # 将灰度图转换为3通道的伪彩色图
    transforms.Resize((224, 224)), # 调整图像大小
    transforms.ToTensor(), # 将图像转换为Tensor
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]), # 归一化
])

# 移除全连接层，以便我们可以添加我们自己的年龄估计层
# 加载预训练的ResNet模型
resnet = models.resnet18(weights=True)
# 获取最后的全连接层的输入特征数量
num_ftrs = resnet.fc.in_features
# 移除全连接层，以便我们可以添加我们自己的年龄估计层
modules = list(resnet.children())[:-1]  # 删除最后的全连接层
resnet = torch.nn.Sequential(*modules)

class AgeEstimationModel(torch.nn.Module):
    def __init__(self):
        super(AgeEstimationModel, self).__init__()
        self.resnet = resnet
        # 使用保存的输入特征数量创建新的全连接层
        self.fc = torch.nn.Linear(num_ftrs, 1)  # 预测年龄

    def forward(self, images):
        features = self.resnet(images)
        features = features.view(features.size(0), -1)  # 将特征展平
        age = self.fc(features)
        return age

# 1. 重建模型结构
model = AgeEstimationModel()

# 2. 加载模型权重
model.load_state_dict(torch.load('age_estimation_model.pth'))
model.eval()  # 设置为评估模式

# 3. 准备数据 (预处理)
def preprocess_image(image_path):
    transform = transforms.Compose([
        transforms.Grayscale(num_output_channels=3),  # 如果是灰度图，确保转为三通道
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])
    image = Image.open(image_path)
    image = transform(image)
    image = image.unsqueeze(0)  # 添加一个批次维度
    return image


# 示例图像路径
image_path = 'test/001.jpg'
image = preprocess_image(image_path)

# 4. 进行预测
with torch.no_grad():  # 禁用梯度计算
    age_pred = model(image)
    print(f'Predicted Age: {age_pred.item()}')